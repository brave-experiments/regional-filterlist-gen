#!/usr/local/opt/python/bin/python3.7

import argparse
from os import path, environ
from tempfile import TemporaryDirectory

import psycopg2
import psycopg2.extras
from PIL import Image
from s3fs.core import S3FileSystem
from tqdm import tqdm

from adsidentifier import AdsIdentifier, update_models

ROWSBATCH = 100


def classify_images(pg_table, id_column, img_path_column, prediction_column, pixel_column, s3=None):
    identifier = AdsIdentifier()

    pg_conn = psycopg2.connect(environ['PG_CONNECTION_STRING'])
    dict_cur = pg_conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    update_cur = pg_conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    dict_cur.execute('select {id}, {imgpath} from {tableName} where {prediction_column} is null'.format(id=id_column,
                                                                                                        imgpath=img_path_column,
                                                                                                        tableName=pg_table,
                                                                                                        prediction_column=prediction_column))

    progress = tqdm(desc='images classification', total=dict_cur.rowcount, unit_scale=True)
    imgs_dict_list = dict_cur.fetchmany(ROWSBATCH)

    while imgs_dict_list:
        with TemporaryDirectory() as temp_dir:
            img_paths_list = []
            filtered_dict_list = []
            pixels_dict_list = []
            for img_dict in imgs_dict_list:
                if img_dict[img_path_column].endswith('.svg'):
                    continue
                if img_dict[img_path_column].startswith('s3://'):
                    bucket, key = split_s3_path(img_dict[img_path_column])
                    local_file = path.join(temp_dir, key.split('/')[-1])
                    try:
                        s3.s3.download_file(bucket, key, local_file)
                    except:
                        print(img_dict[img_path_column])
                        continue
                else:
                    local_file = img_dict[img_path_column]

                width, height = 0, 0
                try:
                    with Image.open(local_file) as img:
                        width, height = img.size
                except:
                    continue

                if width == 1 and height == 1:
                    if pixel_column:
                        img_dict[pixel_column] = True
                    img_dict[prediction_column] = True
                    pixels_dict_list.append(img_dict)
                else:
                    filtered_dict_list.append(img_dict)
                    img_paths_list.append(local_file)

            assert (len(filtered_dict_list) == len(img_paths_list))
            img_predictions = []
            for img in img_paths_list:
                try:
                    img_predictions.append(identifier.predict(img))
                except:
                    img_predictions.append(None)

            assert (len(filtered_dict_list) == len(img_predictions))

            for img_dict, pred in zip(filtered_dict_list, img_predictions):
                if pred is None:
                    img_dict[prediction_column] = None
                else:
                    img_dict[prediction_column] = (pred == '1_Ads')

            if filtered_dict_list:
                psycopg2.extras.execute_values(update_cur,
                                               """UPDATE {table} SET {pred} = data.{pred}
                                                FROM (VALUES %s) AS data ({id}, {pred})
                                                WHERE {table}.{id} = data.{id}"""
                                               .format(table=pg_table, pred=prediction_column, id=id_column),
                                               filtered_dict_list,
                                               template=f"(%({id_column})s, %({prediction_column})s)")
                pg_conn.commit()

            if pixels_dict_list:
                if pixel_column:
                    psycopg2.extras.execute_values(update_cur,
                                                   """UPDATE {table} SET {pred} = data.{pred},
                                                    {pixel} = data.{pixel}
                                                    FROM (VALUES %s) AS data ({id}, {pred}, {pixel})
                                                    WHERE {table}.{id} = data.{id}"""
                                                   .format(table=pg_table, pred=prediction_column,
                                                           id=id_column, pixel=pixel_column),
                                                   pixels_dict_list,
                                                   template=f"(%({id_column})s, %({prediction_column})s, %({pixel_column})s)")
                else:
                    psycopg2.extras.execute_values(update_cur,
                                                   """UPDATE {table} SET {pred} = data.{pred}
                                                    FROM (VALUES %s) AS data ({id}, {pred})
                                                    WHERE {table}.{id} = data.{id}"""
                                                   .format(table=pg_table, pred=prediction_column,
                                                           id=id_column),
                                                   pixels_dict_list,
                                                   template=f"(%({id_column})s, %({prediction_column})s)")
                pg_conn.commit()

        progress.update(len(imgs_dict_list))
        pg_conn.commit()

        imgs_dict_list = dict_cur.fetchmany(ROWSBATCH)
    progress.close()


def split_s3_path(s3path):
    path_parts = s3path.replace("s3://", "").split("/")
    bucket = path_parts.pop(0)
    key = "/".join(path_parts)
    return bucket, key


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Classify all the images from their paths in a Postgres database')

    parser.add_argument('--s3', help='s3 profile or keys for retrieving images in aws buckets', action='store_true')
    parser.add_argument('--aws-profile-name', help='aws profile name')
    parser.add_argument('--aws-access-key', help='aws access key')
    parser.add_argument('--aws-secret-key', help='aws secret key')

    parser.add_argument('--pg-table',
                        help='postgres table with the images to classify', required=True)
    parser.add_argument('--pg-id-column',
                        help='postgres column to use as id for saving the prediction', required=True)
    parser.add_argument('--pg-img-path-column',
                        help='postgres column to use for the images paths', required=True)
    parser.add_argument('--pg-prediction-column',
                        help='postgres column to use for saving the prediction', required=True)
    parser.add_argument('--pg-pixel-column',
                        help='postgres column to flag pixel size images', default=None)
    options = parser.parse_args()

    s3 = None
    if options.s3:
        if options.aws_profile_name is not None:
            s3 = S3FileSystem(anon=False, profile_name=options.aws_profile_name)
        elif options.aws_access_key is not None \
                and options.aws_access_key is not None:
            s3 = S3FileSystem(anon=False, key=options.aws_access_key, secret=options.aws_secret_key)
        else:
            s3 = S3FileSystem(anon=False)

    update_models(s3_fs=s3)
    classify_images(options.pg_table, options.pg_id_column, options.pg_img_path_column, options.pg_prediction_column,
                    options.pg_pixel_column, s3=s3)
