from datetime import datetime, timezone

import pytesseract
from fastai.text import *
from fastai.vision import *
from s3fs import S3FileSystem
from tqdm import tqdm
from unidecode import unidecode

from .ImageTextModel import ImageTextModel, normalize_custom_funcs, collate_mixed

MODELS_DIR = os.path.join(os.path.expanduser('~'), '.ads-identifier', 'ocr-models')


class AdsIdentifierOcr:
    def __init__(self):
        self.vocab = Vocab.load(os.path.join(MODELS_DIR, 'text_vocab.pkl'))
        self.text_databunch = DataBunch.load_empty(MODELS_DIR,
                                                   'text_databunch.pkl')
        self.databunch = DataBunch.load_empty(MODELS_DIR,
                                              'img_txt_databunch.pkl')
        self.encoderLearner = text_classifier_learner(self.text_databunch, AWD_LSTM, drop_mult=0.5)
        self.encoderLearner.load_encoder(os.path.join(MODELS_DIR,
                                                      'text_lm_encoder'))
        self.learn = Learner(self.databunch, ImageTextModel(self.encoderLearner.model))
        self.learn.load(os.path.join(MODELS_DIR, 'img_txt_hybrid'))
        self.learn.data.train_dl.collate_fn = collate_mixed
        self.learn.data.valid_dl.collate_fn = collate_mixed
        self.normalize_img, _ = normalize_custom_funcs(*imagenet_stats)
        self.learn.data.add_tfm(self.normalize_img)

    def predict(self, image_files):
        images_list = listify(image_files)
        img_texts = [unidecode(' '.join(pytesseract.image_to_string(image_file).split())).lower()
                     for image_file in images_list]
        img_list = ImageList(images_list)
        text_list = TextList(img_texts, vocab=self.vocab)
        data_list = MixedItemList([img_list, text_list])
        self.learn.data.add_test(data_list)
        raw_preds, y = self.learn.get_preds(DatasetType.Test)
        preds = [self.learn.data.classes[pred] for pred in np.argmax(raw_preds, 1)]
        return preds[0] if isinstance(image_files, str) else preds


def update_models_ocr(aws_profile_name=None, aws_access_key=None, aws_secret_key=None):
    if not os.path.exists(MODELS_DIR):
        os.makedirs(MODELS_DIR)

    if aws_profile_name is not None:
        s3_fs = S3FileSystem(anon=False, profile_name=aws_profile_name)
    elif aws_access_key is not None \
            and aws_access_key is not None:
        s3_fs = S3FileSystem(anon=False, key=aws_access_key, secret=aws_secret_key)
    else:
        s3_fs = S3FileSystem(anon=False)

    for s3path in s3_fs.glob('s3://com.brave.research.collected-ads/models/img_txt/*'):
        file = s3path.split('/')[-1]
        local_file = os.path.join(MODELS_DIR, file)
        info = s3_fs.info(s3path)
        if (not os.path.exists(local_file)) or \
                info['LastModified'] > datetime.fromtimestamp(os.path.getmtime(local_file), timezone.utc):
            with tqdm(total=info['Size'], unit='B', unit_scale=True, desc=file) as t:
                bucket, key = split_s3_path(s3path)
                s3_fs.s3.download_file(bucket, key, local_file, Callback=hook(t))


def hook(t):
    def inner(bytes_amount):
        t.update(bytes_amount)

    return inner


def split_s3_path(s3path):
    path_parts = s3path.replace("s3://", "").split("/")
    bucket = path_parts.pop(0)
    key = "/".join(path_parts)
    return bucket, key
