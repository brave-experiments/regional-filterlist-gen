from datetime import datetime, timezone

from fastai.vision import *
from s3fs import S3FileSystem
from tqdm import tqdm

MODELS_DIR = os.path.join(os.path.expanduser('~'), '.ads-identifier', 'img-models')
MODEL = models.resnet18


class AdsIdentifier:
    def __init__(self):
        self.learn = load_learner(MODELS_DIR, 'img_resnet18_resizePAD.pkl')

    def predict(self, image_files):
        images_list = listify(image_files)
        self.learn.data.add_test(images_list)
        raw_preds, _ = self.learn.get_preds(DatasetType.Test)
        preds = [self.learn.data.classes[pred] for pred in torch.argmax(raw_preds, 1)]
        return preds[0] if isinstance(image_files, str) else preds

    def predict_with_ad_prob(self, image_files):
        images_list = listify(image_files)
        self.learn.data.add_test(images_list)
        raw_preds, _ = self.learn.get_preds(DatasetType.Test)
        preds = [(self.learn.data.classes[pred], raw_preds[idx, 1].item()) for idx, pred in enumerate(torch.argmax(raw_preds, 1))]
        return preds[0] if isinstance(image_files, str) else preds


def update_models(aws_profile_name=None, aws_access_key=None, aws_secret_key=None, s3_fs=None):
    if not os.path.exists(MODELS_DIR):
        os.makedirs(MODELS_DIR)

    if s3_fs is None:
        if aws_profile_name is not None:
            s3_fs = S3FileSystem(anon=False, profile_name=aws_profile_name)
        elif aws_access_key is not None \
                and aws_access_key is not None:
            s3_fs = S3FileSystem(anon=False, key=aws_access_key, secret=aws_secret_key)
        else:
            s3_fs = S3FileSystem(anon=False)

    for s3path in ['s3://com.brave.research.collected-ads/models/img/img_databunch.pkl'] + s3_fs.glob(
            's3://com.brave.research.collected-ads/models/img/img_{}_resizePAD.*'.format(MODEL.__name__)):
        file = s3path.split('/')[-1]
        local_file = os.path.join(MODELS_DIR, file)
        info = s3_fs.info(s3path)
        if (not os.path.exists(local_file)) or \
                info['LastModified'] > datetime.fromtimestamp(os.path.getmtime(local_file), timezone.utc):
            with tqdm(total=info['Size'], unit='B', unit_scale=True, desc=file) as t:
                bucket, key = split_s3_path(s3path)
                s3_fs.s3.download_file(bucket, key, local_file, Callback=hook(t))


def hook(t):
    def inner(bytes_amount):
        t.update(bytes_amount)

    return inner


def split_s3_path(s3path):
    path_parts = s3path.replace("s3://", "").split("/")
    bucket = path_parts.pop(0)
    key = "/".join(path_parts)
    return bucket, key
