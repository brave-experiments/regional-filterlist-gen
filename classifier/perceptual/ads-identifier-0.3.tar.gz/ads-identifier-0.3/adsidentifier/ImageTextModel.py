from fastai.text import *
from fastai.vision import *


class ImageTextModel(nn.Module):
    def __init__(self, encoder, use_trainer=False):
        self.use_trainer = use_trainer
        super().__init__()
        self.cnn = models.resnet18(pretrained=True, progress=True)
        self.cnn.fc = nn.Linear(512, 32)
        drop = .5
        self.lm_encoder = SequentialRNN(encoder[0], PoolingLinearClassifier([400 * 3, 50, 32], [.2, .1]))
        self.merge = nn.Sequential(*bn_drop_lin(64, 64, bn=True, p=drop, actn=nn.ReLU(inplace=True)))
        self.final = nn.Linear(64, 2)

    def forward(self, img: Tensor, txt: Tensor) -> Tensor:
        img_cnn = self.cnn(img)
        text_latent = self.lm_encoder(txt)

        cat = torch.cat([img_cnn, F.relu(text_latent[0])], dim=1)
        pred = self.final(self.merge(cat))
        if not self.use_trainer:
            return pred
        else:
            return tensor([pred, text_latent])

    def reset(self):
        for c in self.children():
            if hasattr(c, 'reset'): c.reset()


def _normalize_images_batch(b: Tuple[Tensor, Tensor], mean: FloatTensor, std: FloatTensor) -> Tuple[Tensor, Tensor]:
    """`b` = `x`,`y` - normalize `x` array of imgs and `do_y` optionally `y`."""
    x, y = b
    mean, std = mean.to(x[0].device), std.to(x[0].device)
    x[0] = normalize(x[0], mean, std)
    return x, y


def normalize_custom_funcs(mean: FloatTensor, std: FloatTensor, do_x: bool = True, do_y: bool = False) -> Tuple[
    Callable, Callable]:
    """Create normalize/denormalize func using `mean` and `std`, can specify `do_y` and `device`."""
    mean, std = tensor(mean), tensor(std)
    return (partial(_normalize_images_batch, mean=mean, std=std),
            partial(denormalize, mean=mean, std=std))


def collate_mixed(samples, pad_idx: int = 0):
    # Find max length of the text from the MixedItemList
    max_len = max([len(s[0].data[1]) for s in samples])
    for s in samples:
        res = np.zeros(max_len + pad_idx, dtype=np.int64)
        res[:len(s[0].data[1])] = s[0].data[1]
        s[0].data[1] = res

    return data_collate(samples)
