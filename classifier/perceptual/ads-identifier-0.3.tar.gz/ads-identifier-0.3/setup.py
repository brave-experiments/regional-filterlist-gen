#!/usr/bin/env python

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'ads-identifier',
        version = '0.3',
        description = '',
        long_description = '',
        author = '',
        author_email = '',
        license = '',
        url = '',
        scripts = [
            'scripts/classify-images-with-prob.py',
            'scripts/classify-images.py'
        ],
        packages = ['adsidentifier'],
        namespace_packages = [],
        py_modules = [],
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        entry_points = {},
        data_files = [],
        package_data = {},
        install_requires = [
            's3fs',
            'tqdm',
            'torch==1.1.0',
            'torchsummary==1.5.1',
            'torchtext==0.3.1',
            'torchvision==0.3.0',
            'fastai==1.0.55',
            'pytesseract>=0.2.7',
            'unidecode==1.1.1',
            'numpy==1.16.4',
            'psycopg2==2.8.3',
            'fastimage==2.0.0'
        ],
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        keywords = '',
        python_requires = '',
        obsoletes = [],
    )
